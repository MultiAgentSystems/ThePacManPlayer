import sys

SCRIPT_PATH = sys.path[0] + "/pythonPacMan"
